import React from "react"
import { faHotel } from "@fortawesome/free-solid-svg-icons"
import { faPlane } from "@fortawesome/free-solid-svg-icons"
import { faCar } from "@fortawesome/free-solid-svg-icons"
import { faMountainCity } from "@fortawesome/free-solid-svg-icons"
import { faTaxi } from "@fortawesome/free-solid-svg-icons"
import { faCalendarDays } from "@fortawesome/free-solid-svg-icons"
import { faPerson } from "@fortawesome/free-solid-svg-icons"

import { FontAwesomeIcon} from "@fortawesome/react-fontawesome"
import './header.css';
import { useContext } from 'react';
import { SearchContext } from "../../context/SearchContext";

/*date range*/
import { DateRange } from  "react-date-range";
import { useState } from "react";
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext"


const Header = ({ type }) => {
    /*destination state to pass using react router dom*/
    /*empty string rn but whenever we change input, state is updated*/
    const [destination, setDestination] = useState("");

     /* for options of number of people */
    const [openOptions, setOpenOptions] = useState(false);
    const [options, setOptions] = useState({
        adult: 1,
        children: 0,
        room: 1,
    });
    //func to incr decr - set state - return prev state, and name 
    //(in array so that it finds name in our object above) and obtions[name] gives corresponding value of that option
    //condition if i then val ++ else val --
    const handleOption = (name, operation) => {
        setOptions((prev) => {
          return {
            ...prev,
            [name]: operation === "i" ? options[name] + 1 : options[name] - 1,
          };
        });
    };
    
    /*react router dom navigate to redirect users to any component any page and can pass a state*/
    const navigate = useNavigate();
    const { user } = useContext(AuthContext);

    const { dispatch } = useContext(SearchContext);

    const handleSearch = () => {
        dispatch({ type: "NEW_SEARCH", payload: { destination, dates, options } });
        navigate("/hotels", { state: { destination, dates, options } });
    };

    // //for date range
    // // upon refreshing, the date selection area has to go so new useState
    const [openDate, setOpenDate] = useState(false);
    const [dates, setDates] = useState([
      { 
        /*type= javaScript date so use format function of date-fns*/
        /*object(yellow) in array(blue)*/
        startDate: new Date(),
        endDate: new Date(),
        key: "selection",
      },
    ]);
    
    return(
        <div className="header">
            <div 
                className={
                type === "list" ? "headerContainer listMode" : "headerContainer"}>
                {/* give condition for container so that it reflects in /hotels, 
                basically to remove MARGIN(where there was the catchphrase and search bar) in /hotels */}
                
                <div className="headerList">
                    <div className="headerListItem active">
                        <FontAwesomeIcon icon={faHotel} />
                        <span>Stays</span>
                    </div>
                    <div className="headerListItem">
                        <FontAwesomeIcon icon={faPlane} />
                        <span>Flights</span>
                    </div>
                    <div className="headerListItem">
                        <FontAwesomeIcon icon={faCar} />
                        <span>Car rentals</span>
                    </div>
                    <div className="headerListItem">
                        <FontAwesomeIcon icon={faMountainCity} />
                        <span>Attractions</span>
                    </div>
                    <div className="headerListItem">
                        <FontAwesomeIcon icon={faTaxi} />
                        <span>Airport taxis</span>
                    </div>
                </div>
                { type!== "list" && /*if type is NOT list then only this (catchphrase and searchbar) will show*/
                    <><h1 className="headerTitle">Your Gateway to Dream Destinations</h1>
                <p className="headerDesc">Unlock exclusive offers! Book now and embark on a journey of comfort at unbeatable prices.</p>
                {!user && <button className="headerBtn">Sign in / Register</button> 
}
                <div className="headerSearch">
                    {/* destination input */}
                    <div className="headerSearchItem"> 
                        <FontAwesomeIcon icon={faHotel} className="headerIcon" />
                        <input 
                            type="text" 
                            placeholder="Destination" 
                            className="headerSearchInput" 
                            onChange={(e)=>setDestination(e.target.value)}
                        />
                    </div>

                    {/* date range */}
                    <div className="headerSearchItem"> 
                    {/* using react-date-range library */}

                        <FontAwesomeIcon icon={faCalendarDays} className="headerIcon" />

                        {/* clicking on span area will toggle openDate state from true to false (initial) and vice versa */}
                        <span onClick={() => setOpenDate(!openDate)} className="headerSearchText">
                            {/* access 0th index of array and in that, the start date object */}
                            {/* then write the type of format wanted */}
                            {/* repeat for end date*/}
                            {`
                                ${format(dates[0].startDate, "MM/dd/yyyy")} 
                                to 
                                ${format(dates[0].endDate, "MM/dd/yyyy")}
                            `}
                        </span>

                        {/* if openDate state true then this applies */}
                        {openDate && (
                            <DateRange
                                editableDateInputs={true} // Allows user to manually input dates
                                onChange={(item) => setDates([item.selection])} // Event- when we change date, it updates the date
                                moveRangeOnFirstSelection={false} // If true, the first selected day will be added to the range automatically
                                ranges={dates}
                                className="date"
                                minDate={new Date()}
                            />
                        )}
                    </div>

                    {/* number of people */}
                    <div className="headerSearchItem"> 
                        <FontAwesomeIcon icon={faPerson} className="headerIcon" />
                        {/*open and close the options like in date*/}
                        <span onClick={() => setOpenOptions(!openOptions)} className="headerSearchText">
                            {/* dot separated state */}
                            {`${options.adult} adult · ${options.children} children · ${options.room} room`} 
                        </span>
                        
                        {/* if openOptions state true then this applies */}
                        {openOptions && (
                            <div className="options">

                                <div className="optionItem">
                                    <span className="optionText">Adult</span>
                                    <div className="optionCounter">
                                        {/* button with function to increment and decrement passing option and i for incr d for decr
                                        disable the button if a number is invalid ie <1 for adult */}
                                        <button
                                            disabled={options.adult <= 1}
                                            className="optionCounterButton"
                                            onClick={() => handleOption("adult", "d")}
                                        > - </button>
                                        {/* to display number between buttons */}
                                        <span className="optionCounterNumber">
                                            {options.adult}
                                        </span>

                                        <button
                                            className="optionCounterButton"
                                            onClick={() => handleOption("adult", "i")}
                                        > + </button>
                                    </div>
                                </div>

                                <div className="optionItem">
                                    <span className="optionText">Children</span>
                                    <div className="optionCounter">
                                        <button
                                            disabled={options.children <= 0}
                                            className="optionCounterButton"
                                            onClick={() => handleOption("children", "d")}
                                            > - </button>

                                        <span className="optionCounterNumber">
                                            {options.children}
                                        </span>

                                        <button
                                            className="optionCounterButton"
                                            onClick={() => handleOption("children", "i")}
                                        > + </button>
                                    </div>
                                </div>

                                <div className="optionItem">
                                    <span className="optionText">Room</span>
                                    <div className="optionCounter">
                                        <button
                                            disabled={options.room <= 1}
                                            className="optionCounterButton"
                                            onClick={() => handleOption("room", "d")}
                                        > - </button>

                                        <span className="optionCounterNumber">
                                            {options.room}
                                        </span>

                                        <button
                                            className="optionCounterButton"
                                            onClick={() => handleOption("room", "i")}
                                        > + </button>
                                    </div>
                                </div>
                            </div>
                        )}                    
                    </div>

                    {/* search button */}
                    <div className="headerSearchItem"> 
                        <button className="headerBtn" onClick={handleSearch}>Search</button>
                    </div>

                </div></>}
            </div>
        </div>
    );
};

export default Header;
