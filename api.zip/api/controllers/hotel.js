import { isObjectIdOrHexString } from "mongoose";
import Hotel from "../models/Hotel.js";
import Room from "../models/Room.js";

//create
export const createHotel = async (req,res,next)=>{
    const newHotel = new Hotel(req.body);
    
    try {
        const savedHotel = await newHotel.save();
        res.status(200).json(savedHotel);
    } 
    catch (error) {
        next(error);
    }
}
//update
export const updateHotel = async (req,res,next)=>{
    try {
        const updatedHotel = await Hotel.findByIdAndUpdate(
            req.params.id, 
            {$set: req.body},
            {new:true}
        ) ;
        res.status(200).json(updatedHotel);
    } 
    catch (error) {
        next(error);
    }
}
//delete
export const deleteHotel = async (req,res,next)=>{
    try {
        await Hotel.findByIdAndDelete(
            req.params.id
        ) ;
        res.status(200).json("Hotel deleted");
    } 
    catch (error) {
        next(error);
    }
}
//get
export const getHotel = async (req,res,next)=>{
    try {
        const hotel = await Hotel.findById(req.params.id); // Use a different name for the constant
        res.status(200).json(hotel);
    } catch (error) {
        next(error);
    }
}
/*
export const getHotels = async (req, res, next) => {
  const { min, max, ...others } = req.query;
  try {
    const hotels = await Hotel.find({
      ...others,
      cheapestPrice: { $gt: min | 1, $lt: max || 999 },
    }).limit(req.query.limit);
    res.status(200).json(hotels);
  } catch (err) {
    next(err);
  }
};
*/
//get all
export const getHotels = async (req, res, next) => {
    const { min, max, limit, ...others } = req.query;
    try {
      // Parse limit to integer. If not provided or invalid, default to some number or remove limit
      const limitNumber = parseInt(limit, 10);

      const hotelsQuery = Hotel.find({
        ...others,
        cheapestPrice: { $gt: min ? parseInt(min, 10) : 1, $lt: max ? parseInt(max, 10) : 999 },
      });

      // If limitNumber is a valid number, apply it as a limit to the query
      if (limitNumber) {
        hotelsQuery.limit(limitNumber);
      }

      const hotels = await hotelsQuery;
      res.status(200).json(hotels);
    } catch (err) {
      next(err);
    }
};


export const countByCity = async (req, res, next) => {
    const cities = req.query.cities.split(",");
    try {
      const list = await Promise.all( //3 cities
        cities.map((city) => {
          return Hotel.countDocuments({ city: city });//countDocs instead of find cuz find expensive
        })
      );
      res.status(200).json(list);
    } catch (err) {
      next(err);
    }
  };
  export const countByType = async (req, res, next) => {
    try {
      const hotelCount = await Hotel.countDocuments({ type: "hotel" });
      const apartmentCount = await Hotel.countDocuments({ type: "apartment" });
      const resortCount = await Hotel.countDocuments({ type: "resort" });
      const villaCount = await Hotel.countDocuments({ type: "villa" });
      const cabinCount = await Hotel.countDocuments({ type: "cabin" });
  
      res.status(200).json([
        { type: "hotel", count: hotelCount },
        { type: "apartments", count: apartmentCount },
        { type: "resorts", count: resortCount },
        { type: "villas", count: villaCount },
        { type: "cabins", count: cabinCount },
      ]);
    } catch (err) {
      next(err);
    }
  };
  
  export const getHotelRooms = async (req, res, next) => {
    try {
      const hotel = await Hotel.findById(req.params.id);
      const list = await Promise.all(
        hotel.rooms.map((room) => {
          return Room.findById(room);
        })
      );
      res.status(200).json(list)
    } catch (err) {
      next(err);
    }
  };