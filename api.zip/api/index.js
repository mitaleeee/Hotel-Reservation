import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";
import cors from "cors"; 

import authRoute from "./routes/auth.js";
import usersRoute from "./routes/users.js";
import hotelsRoute from "./routes/hotels.js";
import roomsRoute from "./routes/rooms.js";

import cookieParser from "cookie-parser";

const app = express();
dotenv.config();

const connect = async () => {
    try {
        await mongoose.connect(process.env.MONGO);
        console.log("Connected to mongoDB.(initial connection)");
    } 
    catch (error) {
        throw (error);
    }
};


mongoose.connection.on("disconnected", ()=>{
    console.log("MongoDB connection is disconnected.");
});
const database = client.db('booking');
const collection = database.collection('users');

const result = await collection.insertOne({ 
    
    username:"abcd",
    email:"abc@gmail.com",
    password:"$2a$10$dpmbdnd/NWhXK4h2hfRP7uBrtTBuskyLyWasrc2w.kW9Qbbw2d0/q",
    isAdmin:false,
    createdAt:{
        $date:{$numberLong:"1713511597184"}},
        updatedAt:{$date:{$numberLong:"1713511597184"}},
    __v:{$numberInt:0}

});
console.log(`Document inserted with id: ${result.insertedId}`);

//express middlewares
//to access req and response before sending anything to user
//whenever i run my application, its gonna be ready for any api request
//when a user makes an api req, it comes here and checks all middlewares
//next() is go to next middleware
/*
app.use(cors());
app.use(cookieParser())

app.use(express.json())

app.use("/api/auth",authRoute); 
app.use("/api/users",usersRoute);
app.use("/api/hotels",hotelsRoute);
app.use("/api/rooms",roomsRoute);

app.use((err,req,res,next)=>{
    const errorStatus =err.status || 500
    const errorMessage =err.message || "Something went wrong!!!"
    return res.status(errorStatus).json({
        success: false,
        status: errorStatus,
        message: errorMessage,
        stack: err.stack
    })
})
*/
app.listen(8800, ()=>{
    connect();
    console.log("Connected to backend...");
});